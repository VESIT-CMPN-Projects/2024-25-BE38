// package com.example.servlet;

// import com.example.model.Patient;
// import com.example.Util.DBConnection;
// import javax.servlet.ServletException;
// import javax.servlet.annotation.WebServlet;
// import javax.servlet.http.HttpServlet;
// import javax.servlet.http.HttpServletRequest;
// import javax.servlet.http.HttpServletResponse;
// import java.io.IOException;
// import java.sql.Connection;
// import java.sql.PreparedStatement;
// import java.sql.ResultSet;
// import java.util.ArrayList;
// import java.util.List;

// @WebServlet("/patientRecords")
// public class PatientRecordsServlet extends HttpServlet {
//     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//         List<Patient> patients = new ArrayList<>();
//         try (Connection connection = DBUtil.getConnection()) {
//             String query = "SELECT * FROM patients";
//             PreparedStatement statement = connection.prepareStatement(query);
//             ResultSet resultSet = statement.executeQuery();

//             while (resultSet.next()) {
//                 Patient patient = new Patient(
//                     resultSet.getInt("id"),
//                     resultSet.getString("name"),
//                     resultSet.getInt("age"),
//                     resultSet.getString("medicalHistory")
//                 );
//                 patients.add(patient);
//             }
//         } catch (Exception e) {
//             e.printStackTrace();
//         }

//         request.setAttribute("patients", patients);
//         request.getRequestDispatcher("patientRecords.jsp").forward(request, response);
//     }
// }
