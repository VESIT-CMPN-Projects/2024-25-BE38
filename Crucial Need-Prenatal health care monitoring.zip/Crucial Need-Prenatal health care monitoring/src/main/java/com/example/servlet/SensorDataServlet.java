// package com.example.servlet;
// import com.example.Util.DBConnection;
// import com.example.dao.SensorDataDAO;
// import javax.servlet.annotation.WebServlet;
// import javax.servlet.http.HttpServlet;
// import javax.servlet.http.HttpServletRequest;
// import javax.servlet.http.HttpServletResponse;
// import java.io.IOException;
// @WebServlet("/SensorDataServlet")
// public class SensorDataServlet extends HttpServlet {
//     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
//         String motherHeartbeat = request.getParameter("motherHeartbeat");
//         String babyHeartbeat = request.getParameter("babyHeartbeat");
//         String movement = request.getParameter("movement");
//         String userId = request.getParameter("userId");

//         // Save data to the database
//         SensorDataDAO.saveData(userId, motherHeartbeat, babyHeartbeat, movement);

//         response.getWriter().write("Data saved successfully.");
//     }
// }