package com.example.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/SignUpServlet")  // Ensure this matches your form action
public class SignUpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/health_monitoring_db";
    private static final String JDBC_USER = "root";  
    private static final String JDBC_PASSWORD = "abc123";  

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 🔴 Input Validation
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            out.println("<h3 style='color:red;'>All fields are required!</h3>");
            return;
        }

        try {
            // 🔵 Database Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            // 🔵 Check if username already exists
            String checkUserSql = "SELECT username FROM admin_users WHERE username = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkUserSql);
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                out.println("<h3 style='color:red;'>Username already exists. Please choose a different one.</h3>");
                checkStmt.close();
                conn.close();
                return;
            }

            // 🔵 Insert User Data
            String sql = "INSERT INTO admin_users (username, password) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password); // No hashing

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                out.println("<h3>Registration Successful!</h3>");
                out.println("<p>Welcome, " + username + "!</p>");
            } else {
                out.println("<h3 style='color:red;'>Error: Could not register user.</h3>");
            }

            stmt.close();
            conn.close();

        } catch (ClassNotFoundException e) {
            out.println("<h3 style='color:red;'>Database Driver Not Found!</h3>");
        } catch (SQLIntegrityConstraintViolationException e) {
            out.println("<h3 style='color:red;'>Username already exists. Please choose a different one.</h3>");
        } catch (SQLException e) {
            out.println("<h3 style='color:red;'>Database Error! Please try again later.</h3>");
            e.printStackTrace();
        }
    }
}
