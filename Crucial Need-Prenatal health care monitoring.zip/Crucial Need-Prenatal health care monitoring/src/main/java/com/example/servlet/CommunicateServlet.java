// package com.example.servlet;

// import java.io.IOException;
// import java.sql.Connection;
// import java.sql.PreparedStatement;
// import javax.servlet.ServletException;
// import javax.servlet.annotation.WebServlet;
// import javax.servlet.http.HttpServlet;
// import javax.servlet.http.HttpServletRequest;
// import javax.servlet.http.HttpServletResponse;
// import com.example.Util.DBConnection;

// @WebServlet("/communicateServlet")
// public class CommunicateServlet extends HttpServlet {
//     private static final long serialVersionUID = 1L;

//     protected void doPost(HttpServletRequest request, HttpServletResponse response)
//             throws ServletException, IOException {
//         String message = request.getParameter("message");
//         String sender = request.getParameter("sender"); // Doctor/Patient

//         try (Connection conn = DBUtil.getConnection()) {
//             String sql = "INSERT INTO chat (message, sender, timestamp) VALUES (?, ?, NOW())";
//             PreparedStatement stmt = conn.prepareStatement(sql);
//             stmt.setString(1, message);
//             stmt.setString(2, sender);
//             stmt.executeUpdate();

//             response.sendRedirect("communicate.jsp");
//         } catch (Exception e) {
//             e.printStackTrace();
//             response.sendRedirect("dashboard.jsp?error=Unable to send message");
//         }
//     }
// }
