// package com.example.util;
// import com.example.util.DBUtil;
// import java.sql.Connection;
// import java.sql.DriverManager;

// public class DBConnection {
//     private static final String URL = "jdbc:mysql://localhost:3306/health_monitoring";
//     private static final String USER = "root";
//     private static final String PASSWORD = "Pass@123";

//     public static Connection getConnection() throws Exception {
//         Class.forName("com.mysql.cj.jdbc.Driver");
//         return DriverManager.getConnection(URL, USER, PASSWORD);
//     }
// }

// /* mvn clean compile */
// /*mvn tomcat7:run */
// /*mysql -u root -p */
package com.example.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    public static Connection getConnection() throws SQLException {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Open a connection
            String url = "jdbc:mysql://localhost:3306/health_monitoring_db";
            String user = "root";
            String pass = "abc123";
            return DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException e) {
            throw new SQLException("Database connection error", e);
        }
    }
}
