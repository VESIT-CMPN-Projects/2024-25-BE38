package com.example.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SensorDataDAO {
    public static void saveData(String userId, String motherHeartbeat, String babyHeartbeat, String movement) {
        String query = "INSERT INTO Sensor_Data (user_id, mother_heartbeat, baby_heartbeat, movement, timestamp) VALUES (?, ?, ?, ?, NOW())";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/health_monitoring", "root", "password");
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, userId);
            pstmt.setString(2, motherHeartbeat);
            pstmt.setString(3, babyHeartbeat);
            pstmt.setString(4, movement);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
